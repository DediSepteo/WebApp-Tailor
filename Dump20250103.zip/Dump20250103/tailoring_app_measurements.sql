-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: tailoring_app
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `measurements`
--

DROP TABLE IF EXISTS `measurements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measurements` (
  `order_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `measurement` json DEFAULT NULL,
  `product_id` int NOT NULL,
  `qty` int DEFAULT NULL,
  `postal_code` int DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`order_id`,`name`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `measurements_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `measurements_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measurements`
--

LOCK TABLES `measurements` WRITE;
/*!40000 ALTER TABLE `measurements` DISABLE KEYS */;
INSERT INTO `measurements` VALUES (1,'John Doe','123 Main St, Manila','{\"Hip girth\": \"72.19 cm\", \"Bust girth\": \"56.78 cm\", \"Waist girth\": \"58.25 cm\", \"Upper arm girth\": \"34.67 cm\", \"Upper hip girth\": \"66.72 cm\", \"Under bust girth\": \"48.54 cm\", \"Upper chest girth\": \"62.39 cm\"}',1,2,1000,'Manila','639176543210'),(2,'Jane Smith','456 High Rd, Quezon City','{\"Hip girth\": \"75.56 cm\", \"Bust girth\": \"60.12 cm\", \"Waist girth\": \"59.87 cm\", \"Upper arm girth\": \"35.14 cm\", \"Upper hip girth\": \"70.10 cm\", \"Under bust girth\": \"50.33 cm\", \"Upper chest girth\": \"65.45 cm\"}',2,3,1101,'Quezon City','639185432109'),(3,'Carlos Dela Cruz','789 Ocean Dr, Cebu City','{\"Hip girth\": \"73.90 cm\", \"Bust girth\": \"58.34 cm\", \"Waist girth\": \"57.45 cm\", \"Upper arm girth\": \"34.21 cm\", \"Upper hip girth\": \"68.20 cm\", \"Under bust girth\": \"49.28 cm\", \"Upper chest girth\": \"63.78 cm\"}',3,4,6000,'Cebu City','639174321987'),(4,'Anna Reyes','101 Palm Ave, Makati','{\"Hip girth\": \"71.45 cm\", \"Bust girth\": \"55.47 cm\", \"Waist girth\": \"56.10 cm\", \"Upper arm girth\": \"33.87 cm\", \"Upper hip girth\": \"65.80 cm\", \"Under bust girth\": \"47.90 cm\", \"Upper chest girth\": \"61.22 cm\"}',4,2,1224,'Makati','639176543211'),(5,'Liam Santos','202 Ridge Rd, Davao City','{\"Hip girth\": \"74.63 cm\", \"Bust girth\": \"59.23 cm\", \"Waist girth\": \"60.34 cm\", \"Upper arm girth\": \"36.19 cm\", \"Upper hip girth\": \"67.42 cm\", \"Under bust girth\": \"51.12 cm\", \"Upper chest girth\": \"64.85 cm\"}',5,1,8000,'Davao City','639189876543'),(6,'Emily Garcia','789 Vogue Blvd, Cebu City','{\"Hip girth\": \"72.88 cm\", \"Bust girth\": \"57.19 cm\", \"Waist girth\": \"58.23 cm\", \"Upper arm girth\": \"35.02 cm\", \"Upper hip girth\": \"66.32 cm\", \"Under bust girth\": \"48.99 cm\", \"Upper chest girth\": \"62.45 cm\"}',6,3,6001,'Cebu City','639176547891'),(7,'Noah Cruz','555 Needle Rd, Pasig','{\"Hip girth\": \"74.12 cm\", \"Bust girth\": \"58.45 cm\", \"Waist girth\": \"59.75 cm\", \"Upper arm girth\": \"34.78 cm\", \"Upper hip girth\": \"68.20 cm\", \"Under bust girth\": \"49.56 cm\", \"Upper chest girth\": \"64.11 cm\"}',7,2,1600,'Pasig','639176548765'),(8,'Sophia Lim','202 Design St, Makati','{\"Hip girth\": \"70.89 cm\", \"Bust girth\": \"54.89 cm\", \"Waist girth\": \"55.30 cm\", \"Upper arm girth\": \"33.45 cm\", \"Upper hip girth\": \"64.22 cm\", \"Under bust girth\": \"46.75 cm\", \"Upper chest girth\": \"60.45 cm\"}',8,3,1225,'Makati','639187654321'),(9,'Ethan Tan','321 Sharp Rd, Manila','{\"Hip girth\": \"76.22 cm\", \"Bust girth\": \"60.12 cm\", \"Waist girth\": \"61.02 cm\", \"Upper arm girth\": \"36.80 cm\", \"Upper hip girth\": \"69.70 cm\", \"Under bust girth\": \"51.34 cm\", \"Upper chest girth\": \"66.15 cm\"}',9,4,1002,'Manila','639176543213'),(10,'Olivia Ramos','77 Tailor Blvd, Bacolod','{\"Hip girth\": \"72.11 cm\", \"Bust girth\": \"55.78 cm\", \"Waist girth\": \"57.45 cm\", \"Upper arm girth\": \"33.89 cm\", \"Upper hip girth\": \"65.95 cm\", \"Under bust girth\": \"48.22 cm\", \"Upper chest girth\": \"61.90 cm\"}',10,2,6100,'Bacolod','639176543567'),(11,'Jacob Chua','99 Fashion Lane, Iloilo','{\"Hip girth\": \"73.34 cm\", \"Bust girth\": \"57.67 cm\", \"Waist girth\": \"58.85 cm\", \"Upper arm girth\": \"34.54 cm\", \"Upper hip girth\": \"66.90 cm\", \"Under bust girth\": \"49.88 cm\", \"Upper chest girth\": \"63.70 cm\"}',11,1,5000,'Iloilo','639174321999'),(12,'Isabella Reyes','555 Needle Rd, Pasig','{\"Hip girth\": \"71.20 cm\", \"Bust girth\": \"56.12 cm\", \"Waist girth\": \"56.89 cm\", \"Upper arm girth\": \"33.90 cm\", \"Upper hip girth\": \"65.70 cm\", \"Under bust girth\": \"47.45 cm\", \"Upper chest girth\": \"62.30 cm\"}',12,3,1601,'Pasig','639189874563'),(13,'Mia Mendoza','101 Palm Ave, Makati','{\"Hip girth\": \"74.12 cm\", \"Bust girth\": \"59.34 cm\", \"Waist girth\": \"60.10 cm\", \"Upper arm girth\": \"36.45 cm\", \"Upper hip girth\": \"67.11 cm\", \"Under bust girth\": \"50.87 cm\", \"Upper chest girth\": \"65.22 cm\"}',13,2,1226,'Makati','639176543214'),(14,'Daniel Sy','202 Ridge Rd, Davao City','{\"Hip girth\": \"73.78 cm\", \"Bust girth\": \"58.88 cm\", \"Waist girth\": \"59.55 cm\", \"Upper arm girth\": \"35.67 cm\", \"Upper hip girth\": \"67.50 cm\", \"Under bust girth\": \"49.99 cm\", \"Upper chest girth\": \"64.75 cm\"}',14,1,8001,'Davao City','639187654332'),(15,'Emma Perez','789 Vogue Blvd, Cebu City','{\"Hip girth\": \"70.23 cm\", \"Bust girth\": \"54.90 cm\", \"Waist girth\": \"55.30 cm\", \"Upper arm girth\": \"33.10 cm\", \"Upper hip girth\": \"64.12 cm\", \"Under bust girth\": \"47.10 cm\", \"Upper chest girth\": \"61.10 cm\"}',15,3,6002,'Cebu City','639185432222'),(16,'Lucas Fernandez','123 Green Lane, Taguig','{\"Hip girth\": \"73.80 cm\", \"Bust girth\": \"57.50 cm\", \"Waist girth\": \"58.20 cm\", \"Upper arm girth\": \"34.80 cm\", \"Upper hip girth\": \"67.00 cm\", \"Under bust girth\": \"48.60 cm\", \"Upper chest girth\": \"63.40 cm\"}',16,2,1630,'Taguig','639176548123'),(17,'Chloe Navarro','456 Heritage Rd, Quezon City','{\"Hip girth\": \"72.10 cm\", \"Bust girth\": \"56.30 cm\", \"Waist girth\": \"56.70 cm\", \"Upper arm girth\": \"33.60 cm\", \"Upper hip girth\": \"65.90 cm\", \"Under bust girth\": \"47.20 cm\", \"Upper chest girth\": \"62.90 cm\"}',17,3,1102,'Quezon City','639185432123'),(18,'Aiden Valdez','789 Baywalk Blvd, Cebu City','{\"Hip girth\": \"74.30 cm\", \"Bust girth\": \"58.10 cm\", \"Waist girth\": \"59.40 cm\", \"Upper arm girth\": \"35.30 cm\", \"Upper hip girth\": \"68.50 cm\", \"Under bust girth\": \"49.70 cm\", \"Upper chest girth\": \"64.60 cm\"}',18,1,6003,'Cebu City','639174321654'),(19,'Grace Sison','101 Garden St, Baguio','{\"Hip girth\": \"71.50 cm\", \"Bust girth\": \"55.70 cm\", \"Waist girth\": \"56.20 cm\", \"Upper arm girth\": \"33.80 cm\", \"Upper hip girth\": \"65.30 cm\", \"Under bust girth\": \"47.50 cm\", \"Upper chest girth\": \"61.80 cm\"}',19,4,2600,'Baguio','639176543876'),(20,'Ethan Cruz','202 Summit Ave, Davao City','{\"Hip girth\": \"76.20 cm\", \"Bust girth\": \"59.20 cm\", \"Waist girth\": \"60.70 cm\", \"Upper arm girth\": \"36.50 cm\", \"Upper hip girth\": \"69.00 cm\", \"Under bust girth\": \"51.00 cm\", \"Upper chest girth\": \"66.00 cm\"}',20,3,8002,'Davao City','639189874567');
/*!40000 ALTER TABLE `measurements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-03 11:52:33
