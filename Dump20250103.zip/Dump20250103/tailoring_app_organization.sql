-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: tailoring_app
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization` (
  `org_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(125) NOT NULL,
  `email` varchar(255) NOT NULL,
  `industry` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `address_line1` varchar(255) NOT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `postal_code` varchar(32) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` varchar(25) NOT NULL,
  PRIMARY KEY (`org_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'TechVision Solutions','contact@techvision.com','Technology','Corporate','securepassword123','active','Manila','Philippines','123 Tech Park',NULL,'1000','Metro Manila','639171234567'),(2,'EcoHarvest Co.','info@ecoharvest.com','Agriculture','Corporate','greenworld456','active','Cebu City','Philippines','45 Green Lane',NULL,'6000','Cebu','639188765432'),(3,'HealthFirst Inc.','support@healthfirst.com','Healthcare','Corporate','healthcare789','inactive','Quezon City','Philippines','789 Wellness Ave','Suite 200','1101','Metro Manila','639198765123'),(4,'BuildPro Enterprises','contact@buildpro.com','Construction','Corporate','builder101','active','Davao City','Philippines','67 Progress Blvd',NULL,'8000','Davao del Sur','639182345678'),(5,'EduGrow Learning','hello@edugrow.com','Education','Corporate','learnnow555','active','Pasig','Philippines','22 Knowledge St',NULL,'1600','Metro Manila','639174567890'),(6,'CyberSecurity Solutions','secure@cybersec.com','Technology','Corporate','cyber12345','inactive','Makati','Philippines','456 Secure Dr','Unit 5','1226','Metro Manila','639175432187'),(7,'QuickTransport Inc.','info@quicktransport.com','Logistics','Corporate','transit202','active','Taguig','Philippines','88 Mobility Ln',NULL,'1630','Metro Manila','639184321765'),(8,'GreenEnergy Innovations','contact@greenenergy.com','Energy','Corporate','renewable001','inactive','Bacolod City','Philippines','55 Solar Ave',NULL,'6100','Negros Occidental','639181234876'),(9,'UrbanStyle Design','design@urbanstyle.com','Fashion','Corporate','fashionista789','active','Baguio','Philippines','99 Trendy Rd',NULL,'2600','Benguet','639198765432'),(10,'SmartFinance Corp.','finance@smartfinance.com','Finance','Corporate','financepro101','active','Cagayan de Oro','Philippines','78 Money Blvd','Level 2','9000','Misamis Oriental','639193456789'),(11,'RuralBanking PH','services@ruralbanking.com','Banking','Government','securebank456','inactive','Dumaguete City','Philippines','12 Savings St',NULL,'6200','Negros Oriental','639192345678'),(12,'AgroGov Initiatives','connect@agrogov.com','Agriculture','Government','farming789','active','Iloilo City','Philippines','34 Crop Rd',NULL,'5000','Iloilo','639185432198'),(13,'HealthCare Trust','admin@healthcaretrust.com','Healthcare','Government','trustme007','inactive','Tacloban City','Philippines','67 Health Ave',NULL,'6500','Leyte','639187654321'),(14,'InfraGov Projects','infra@infragov.com','Infrastructure','Government','infra2021','active','Zamboanga City','Philippines','45 Bridge Rd',NULL,'7000','Zamboanga del Sur','639186543210'),(15,'TechGov Innovations','innovate@techgov.com','Technology','Government','govtech999','active','Caloocan','Philippines','89 Future Blvd','Suite 3','1400','Metro Manila','639184567321'),(16,'CleanCity Sanitation','help@cleancity.com','Sanitation','Government','cleancity123','active','Las Piñas','Philippines','101 Clean Rd',NULL,'1740','Metro Manila','639194321098'),(17,'CulturalHeritage Office','culture@heritage.gov.ph','Cultural','Government','heritage456','inactive','Vigan City','Philippines','12 History Ln',NULL,'2700','Ilocos Sur','639193214567'),(18,'DisasterRelief PH','contact@relief.ph','Disaster Management','Government','helpme321','active','Ormoc City','Philippines','76 Relief Dr',NULL,'6541','Leyte','639184321098'),(19,'MetroHousing Authority','housing@metrohousing.com','Housing','Government','housing789','active','Mandaluyong','Philippines','34 Shelter Blvd',NULL,'1550','Metro Manila','639183456789'),(20,'WaterWorks PH','water@waterworks.ph','Utilities','Government','watersafe001','inactive','San Fernando','Philippines','78 Aqua St',NULL,'2000','Pampanga','639187654123'),(21,'test','turtle.king911@gmail.com','Technology','Corporate','$2b$10$40H.dy3lSHLOOq5jY6G9JOUrY5KzAntDmV3NYmwGH6ET1ZZ7/ZfIu','active','sg','SG','abc123','','123456','sg','123');
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-03 11:52:33
